#!/bin/bash
# RST_EQ_GS.sh
#  Generate gaussian input file for re-optimizing 
#   approximate equilibrium structures
# Yukihiro Ota (ohta.yukihiro@jaea.go.jp)
# June 18, 2015
EQSTA=0
EQEND=21
EQDDD=1

### standard input of gaussian09
# Link0
INCHK=$(echo "%Chk=chk.g09")   # check point file
INPRC=$(echo "%Nproc=8")        # number of processes
# Root section
INRTS=$(echo -e "#p RB3LYP/LANL2DZ Opt SCF=TIGHT NOSYMM Test")
# Comment
INCMT=$(echo "Opt by B3LYP Cellulose1 OH H and Cs ion")
# Charge and spin multiplicity
INCAM=$(echo "1 1")


#######################
CWDN=$PWD

IEQ=$EQSTA
while [ "$IEQ" -le "$EQEND" ] ; do
    INXYZ=$(echo "EQ"$IEQ".xyz")
    GSINP=$(echo $CWDN"/EQ"$IEQ"/proj.com")
    echo $INXYZ
    echo $GSINP
    if [ -f "$GSINP" ] ; then
	cp $GSINP $GSINP.old
	rm $GSINP
    fi
    ### input
    echo $INCHK >> $GSINP
    echo $INPRC >> $GSINP
    echo $INRTS >> $GSINP
    echo "" >> $GSINP
    echo $INCMT "EQ" $IEQ >> $GSINP
    echo "" >> $GSINP
    echo $INCAM >> $GSINP
    tail -n +3 $INXYZ >> $GSINP
    echo "" >> $GSINP
    echo ""
    IEQ=$((IEQ+EQDDD))
done
