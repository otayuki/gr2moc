#!/bin/bash
# Script for extracting GRRM/AFIR output
#  Yukihiro Ota (ohta.yukihiro@jaea.go.jp) Jun 2, 2015
#
# IMPORTANT!!IMPORTANT!!IMPORTANT!!IMPORTANT!!IMPORTANT!!
#  You must specify the total number of atoms with "NATMS"
# IMPORTANT!!IMPORTANT!!IMPORTANT!!IMPORTANT!!IMPORTANT!!
#
#[input data]
#(note. xxxx is specified by input variable "NPROJ")
# xxxx_EQ_list.log 
# xxxx_EQn.log     (n=0,1,2,...)
#[output]
# EQENE_DAT       : Energy (and spin) of each equilibrium structure
# EQn.xyz         : XYZ-format file of struture EQn (n=0,1,2...)
# ./EQn           : Directory of output data from xxxx_EQn.log
# |                 (automatically created)
# |--ITRmmmm.xyz  : XYZ-format file of structure at each iteration
# |                 (0-filled 4-digit mmmm specifies iteration step, 
# |                 e.g., 0000, 0010, etc.)
# |--AFIR_PATH_DAT: AFIR path information (optional)
# 
NATMS=25                        # number of atoms in your input file
TARGD=$(echo "..")   # data directory
NPROJ=proj                      # name of your project ("NPROJ".com) 
ITRWD=32                        # width of iteration processes
ITRD=0                          # You need iteration data -> 1 
AFIR=1                          # AFIR -> 1 / No AFIR -> 0 

#################################
# NEVER EDIT THE FOLLOWING PART
#################################
#-----Definition of functions
set_index () {
 
 if [ "$1" -le "9" ] ; then
    local ii=000"$1"
 elif [ "$1" -le "99" ] ; then
    local ii=00"$1"
 elif [ "$1" -le "999" ] ; then
    local ii=0"$1"
 elif [ "$1" -le "9999" ] ; then
    local ii="$1"
 else
    echo "Overflow occurs in set_index"
    return 1 
 fi
 echo $ii
 return 0
}
#-----end

### Set the current working directory 
CWDN=$PWD
### Extract data from xxx_EQ_list.log
FN_EQLIST=$(echo $TARGD"/"$NPROJ"_EQ_list.log")
EQLIST=($(less $FN_EQLIST |grep -E -i -n "Geometry of EQ" |sed 's/:.*$//g'))
EQNAME=($(less $FN_EQLIST |grep -E -i "Geometry of EQ" \
    |sed 's/^.*EQ //g' |sed 's/,.*$//g'))
### output file of energy data
OUTEN=$(echo $CWDN"/EQENE_DAT")
LOGEN=$(echo $CWDN"/EQENE_LOG")
if [ -f "$OUTEN" ] ;then
    cp $OUTEN $OUTEN.old
    rm $OUTEN
fi
### Equilibrium structure
i=0
while [ "$i" -lt "${#EQLIST[@]}" ] ;do
    OUTFN=$(echo $CWDN"/EQ"${EQNAME[i]}".xyz")
    ## delete old xyz data
    if [ -f "$OUTFN" ] ;then
	rm $OUTFN
    fi
    ## region of geometry data
    LHEAD=$((EQLIST[i] + NATMS))
    LTAIL=$((NATMS + 1))
    ## energy, spin, ZPVE line
    ENLNE=$((EQLIST[i] + NATMS +1))
    SPLNE=$((EQLIST[i] + NATMS +2))
    #ZPLNE=$((EQLIST[i] + NATMS +3))
    ## Make xyz file of Approximate EQ state
    echo $NATMS > $OUTFN
    head -n $LHEAD $FN_EQLIST |tail -n $LTAIL >> $OUTFN
    ## Make energy data
    ENV=$(head -n $ENLNE $FN_EQLIST |tail -n 1 \
	|sed 's/^.*= //' |sed 's/ (.*$//g')
    SPV=$(head -n $SPLNE $FN_EQLIST |tail -n 1 \
	|sed 's/^.*= //')
    #head -n $ZPLNE $FN_EQLIST |tail -n 1 
    echo  ${EQNAME[i]} $ENV $SPV >> $LOGEN

    i=$((i+1))
done
### Make energy data file sorting in descending order
echo "# Rank EQ Energy(Ha) Spin " > $OUTEN
sort -g -k 2 $LOGEN |cat -b >> $OUTEN
rm $LOGEN
#### Gnuplot input file for EQENE_DAT
ENE0=$(awk '($1==1){print $3}' $OUTEN)
PLTEN=$(echo $CWDN"/EQENE.plt")
if [ -f "$PLTEN" ] ; then
    cp $PLTEN $PLTEN.old
    rm $PLTEN
fi 
echo "set terminal postscript eps enhanced color \\" >> $PLTEN
echo "dashed \"Arial,22\"" >> $PLTEN
echo "set style line 1 lt 2 lc 1 lw 3 pt 4 ps 2.5" >> $PLTEN
echo "set style line 2 lt 2 lc 9 lw 3 pt 7 ps 1.5" >> $PLTEN
echo "set style line 3 lt 3 lc 5 lw 2 pt 6 ps 2.5" >> $PLTEN
echo "set style line 4 lt 3 lc 7 lw 2 pt 7 ps 2.5" >> $PLTEN
echo "set style line 5 lt 3 lc 2 lw 2 pt 8 ps 2.5" >> $PLTEN
echo "set style line 6 lt 3 lc 4 lw 2 pt 1 ps 2.5" >> $PLTEN
echo "set style line 7 lt 3 lc 6 lw 2 pt 2 ps 2.5" >> $PLTEN
echo "set style line 8 lt 3 lc 0 lw 2 pt 3 ps 0.5" >> $PLTEN
echo "set style line 9 lt 2 lc 0 lw 2 pt 4 ps 0.5" >> $PLTEN
echo "#" >> $PLTEN
echo "ha_to_kcm=627.50955314995" >> $PLTEN
echo "eneup=ha_to_kcm*1.4e-2" >> $PLTEN
echo "enetics=1.8" >> $PLTEN
echo "set size 0.8,0.56" >> $PLTEN
echo "set xrange [0.7:3.5]" >> $PLTEN
echo "set yrange [0.0:eneup]" >> $PLTEN
echo "#set y2range [-0.7:2.3]" >> $PLTEN
echo "set xtics 1" >> $PLTEN
echo "set ytics enetics" >> $PLTEN
echo "#set ytics enetics nomirror" >> $PLTEN
echo "#set y2tics 1" >> $PLTEN
echo "set xlabel 'Structure'" >> $PLTEN
echo "set ylabel 'Energy (kcal/mol)'" >> $PLTEN
echo "#set y2label 'Structure'" >> $PLTEN
echo "#set format y \"%.2e\"" >> $PLTEN
echo "# Energy basepoint" >> $PLTEN
echo "ENE0="$ENE0 >> $PLTEN
echo "#" >> $PLTEN
echo "set output \"EQENE_DAT.eps\"" >> $PLTEN
echo "plot \\" >> $PLTEN
echo "'EQENE_DAT' using 1:(ha_to_kcm*(\$3-ENE0)) title '' axes x1y1 with linespoint ls 1" >> $PLTEN
echo "#plot \\" >> $PLTEN
echo "#'EQENE_DAT' using 1:(ha_to_kcm*(\$3-ENE0)) title '' axes x1y1 with linespoint ls 1,\\" >> $PLTEN
echo "#'EQENE_DAT' using 1:2 title '' axes x1y2 with linespoint ls 2" >> $PLTEN
echo "set output" >> $PLTEN

### Each EQ-list log
unset FN_EQLIST
unset OUTFN
unset LHEAD
unset LTAIL
i=0
while [ "$i" -lt "${#EQLIST[@]}" ] ;do
    FN_EQLIST=$(echo $TARGD"/"$NPROJ"_EQ"${EQNAME[i]}".log")
    DN_EQLIST=$(echo $CWDN"/EQ"${EQNAME[i]})
    if [ ! -d  "$DN_EQLIST" ] ; then
	mkdir $DN_EQLIST
    fi
    ## maximum of iteration 
    ITR_MAX=$(grep -E "ITR" $FN_EQLIST |tail -n 1 |sed 's/^.*\. //')
    if [ "$ITRD" -eq "1" ] ; then
      ## delete old xyz files
      if [ -d  "$DN_EQLIST" ] ; then
	    rm -f $DN_EQLIST/*.xyz
      fi
      ii=0
      while [ "$ii" -le "$ITR_MAX" ] ; do
	ITR_CNT=$(echo "# ITR. "$ii)
	ITRLIST=$(echo "grep -E -w -n \""$ITR_CNT"\"" $FN_EQLIST |sh \
	    |sed 's/:.*$//g')
	LHEAD=$((ITRLIST + NATMS))
	LTAIL=$((NATMS + 1))
        ## Make xyz file at each iteration step
	idx_ii=$(set_index $ii)
	if [ "$?" -eq "1" ] ; then
	    exit
	fi
	OUTFN=$(echo $DN_EQLIST"/ITR"$idx_ii".xyz")
	echo $NATMS > $OUTFN
	head -n $LHEAD $FN_EQLIST |tail -n $LTAIL >> $OUTFN
	ii=$((ii + ITRWD))
      done
    fi 
    ## AFIR path
    if [ "$AFIR" -eq "1" ] ; then
	unset ENE0
	OUTAF=$(echo $DN_EQLIST"/AFIR_PATH_DAT")
	if [ -f "$OUTAF" ] ; then
	    cp $OUTAF $OUTAF.old
	    rm $OUTAF
	fi
	AFHEAD=$(grep -E -n "Profile of AFIR path" $FN_EQLIST \
	    |sed 's/:.*$//g')
	echo -n "#" > $OUTAF
	head -n $AFHEAD $FN_EQLIST |tail -n 1 >> $OUTAF
	echo -n "#" >> $OUTAF
	head -n $((AFHEAD+1)) $FN_EQLIST |tail -n 1  >> $OUTAF
	tail -n +$((AFHEAD+2)) $FN_EQLIST \
	    |awk '(v != 1){print $0;if($1=="") v=1}' >> $OUTAF
	## gnuplot input for AFIR_PATH_DAT
	PLTAF=$(echo $DN_EQLIST"/AF.plt")
	if [ -f "$PLTAF" ] ; then
	    cp $PLTAF $PLTAF.old
	    rm $PLTAF
	fi 
	AFIRXTICS=$((ITR_MAX / 4))
	if [ "$AFIRXTICS" -eq "0" ] ;then
	    AFIRXTICS=1
	fi
	ENE0=$(awk '($1==0){print $4}' $OUTAF)
	echo "set terminal postscript eps enhanced color \\" >> $PLTAF
	echo "dashed \"Arial,22\"" >> $PLTAF
	echo "set style line 1 lt 3 lc 1 lw 1 pt 4 ps 0.7 " >> $PLTAF
	echo "set style line 2 lt 2 lc 9 lw 1 pt 7 ps 1.5 " >> $PLTAF
	echo "set style line 3 lt 3 lc 5 lw 2 pt 6 ps 2.5 " >> $PLTAF
	echo "set style line 4 lt 3 lc 7 lw 2 pt 7 ps 2.5 " >> $PLTAF
	echo "set style line 5 lt 3 lc 2 lw 2 pt 8 ps 2.5 " >> $PLTAF
	echo "set style line 6 lt 3 lc 4 lw 2 pt 1 ps 2.5 " >> $PLTAF
	echo "set style line 7 lt 3 lc 6 lw 2 pt 2 ps 2.5 " >> $PLTAF
	echo "set style line 8 lt 3 lc 0 lw 2 pt 3 ps 0.5 " >> $PLTAF
	echo "set style line 9 lt 2 lc 0 lw 2 pt 4 ps 0.5 " >> $PLTAF
	echo "# Energy base point" >> $PLTAF
	echo "ENE0="$ENE0 >> $PLTAF 
	echo "set size 0.8,0.8" >> $PLTAF
	echo "set xrange [0:"$ITR_MAX"]" >> $PLTAF
	echo "set xtics "$AFIRXTICS >> $PLTAF
	echo "set xlabel 'Itr.' " >> $PLTAF
	echo "set ylabel 'Energy (Hartree)' " >> $PLTAF
	echo "set output \"AFIR_PATH.eps\"" >> $PLTAF
	echo "plot \\" >> $PLTAF
	echo "'AFIR_PATH_DAT' using 1:(\$4-ENE0) title '' with linespoint ls 1 " >> $PLTAF
	echo "set output" >> $PLTAF
    fi
    i=$((i+1))
done
